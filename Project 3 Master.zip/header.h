//
// Created by work on 10/16/2021.
//

#ifndef PROJECT1_STARTER_CODE_HEADER_H
#define PROJECT1_STARTER_CODE_HEADER_H

#include <vector>
#include <string>

struct header{
    std::vector<std::string> head;
    int size;
};
#endif //PROJECT1_STARTER_CODE_HEADER_H
